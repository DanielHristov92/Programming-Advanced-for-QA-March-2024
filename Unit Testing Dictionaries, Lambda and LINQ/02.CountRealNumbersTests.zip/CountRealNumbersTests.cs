using NUnit.Framework;

using System;
using System.Text;

namespace TestApp.Tests;

public class CountRealNumbersTests
{
    // TODO: finish test
    [Test]
    public void Test_Count_WithEmptyArray_ShouldReturnEmptyString()
    {
        // Arrange
        int[] nums = new int[0];

        // Act
        string result = CountRealNumbers.Count(nums);

        // Assert
        Assert.That(result, Is.Empty);
    }

    [Test]
    public void Test_Count_WithSingleNumber_ShouldReturnCountString()
    {
        // Arrange
        int[] nums = { 96 };
        string expectedResult = "96 -> 1";

        // Act
        string result = CountRealNumbers.Count(nums);

        // Assert
        Assert.That(result, Is.EqualTo(expectedResult));
    }

    [Test]
    public void Test_Count_WithMultipleNumbers_ShouldReturnCountString()
    {
        // Arrange
        int[] nums = { 2, 5, 2, 8, 6 };
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("2 -> 2");
        sb.AppendLine("5 -> 1");
        sb.AppendLine("6 -> 1");
        sb.AppendLine("8 -> 1");

        string expectedResult = sb.ToString().TrimEnd();

        // Act
        string result = CountRealNumbers.Count(nums);

        // Assert
        Assert.That(result, Is.EqualTo(expectedResult));
    }

    [Test]
    public void Test_Count_WithNegativeNumbers_ShouldReturnCountString()
    {
        // Arrange
        int[] nums = { -5, -1010, -15, -1, -5 };
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("-1010 -> 1");
        sb.AppendLine("-15 -> 1");
        sb.AppendLine("-5 -> 2");
        sb.AppendLine("-1 -> 1");

        string expectedResult = sb.ToString().TrimEnd();

        // Act
        string result = CountRealNumbers.Count(nums);

        // Assert
        Assert.That(result, Is.EqualTo(expectedResult));
    }

    [Test]
    public void Test_Count_WithZero_ShouldReturnCountString()
    {
        // Arrange
        int[] nums = { 0, -10, -15, 10, 15, 0, -15 };
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("-15 -> 2");
        sb.AppendLine("-10 -> 1");
        sb.AppendLine("0 -> 2");
        sb.AppendLine("10 -> 1");
        sb.AppendLine("15 -> 1");

        string expectedResult = sb.ToString().TrimEnd();

        // Act
        string result = CountRealNumbers.Count(nums);

        // Assert
        Assert.That(result, Is.EqualTo(expectedResult));
    }
}
