using System;

namespace Shapes;

public interface IDrawable
{
    void Draw();
}
public interface ICircle : IDrawable
{
    int Radius { get; }
}

public class Circle : ICircle
{
    public int Radius { get; }

    public Circle(int radius)
    {
        Radius = radius;
    }

    public void Draw()
    {
        double rIn = Radius - 0.4;
        double rOut = Radius + 0.4;

        for (double y = Radius; y >= -Radius; --y)
        {
            for (double x = -Radius; x < rOut; x += 0.5)
            {
                double value = x * x + y * y;
                if (value >= rIn * rIn && value <= rOut * rOut)
                    Console.Write("*");
                else
                    Console.Write(" ");
            }
            Console.WriteLine();
        }
    }
}

public class Rectangle : IDrawable
{
    private int Width { get; }
    private int Height { get; }

    public Rectangle(int width, int height)
    {
        Width = width;
        Height = height;
    }

    public void Draw()
    {
        for (int i = 0; i < Height; i++)
        {
            for (int j = 0; j < Width; j++)
            {
                if (i == 0 || i == Height - 1 || j == 0 || j == Width - 1)
                    Console.Write("*");
                else
                    Console.Write(" ");
            }
            Console.WriteLine();
        }
    }
}